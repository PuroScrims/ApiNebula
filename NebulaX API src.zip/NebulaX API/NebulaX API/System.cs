﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Media.Imaging;
using System.Xml.Linq;
using Newtonsoft.Json.Linq;

namespace NebulaX_API
{
    public class System
    {
        [DllImport("bin\\NebulaX.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern void Inject();

        [DllImport("bin\\NebulaX.dll", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.Cdecl)]
        public static extern void Execute(string input);

        [DllImport("bin\\NebulaX.dll", CallingConvention = CallingConvention.Cdecl)]
        [return: MarshalAs(UnmanagedType.I1)]
        public static extern bool IsInjected();

        [DllImport("kernel32.dll")]
        static extern bool AllocConsole();
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern IntPtr GetModuleHandle(string lpModuleName);

        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern bool FreeLibrary(IntPtr hModule);

        [DllImport("kernel32.dll")]
        private static extern IntPtr CreateThread(
            IntPtr lpThreadAttributes,
            uint dwStackSize,
            IntPtr lpStartAddress,
            IntPtr lpParameter,
            uint dwCreationFlags,
            out uint lpThreadId);

        public static void ShowDebugConsole()
        {
            AllocConsole();
            var stdOut = Console.OpenStandardOutput();
            Console.SetOut(new StreamWriter(stdOut) { AutoFlush = true });
            Console.Title = "NebulaX API DEBUG CONSOLE";
            Console.WriteLine("NebulaX API BY OG12345\n");
        }

        public static bool isRobloxOpen()
        {
            return Process.GetProcessesByName("RobloxPlayerBeta").Length != 0;
        }

        public static void KillRoblox()
        {
            if (isRobloxOpen())
            {
                Process[] processesbyname = Process.GetProcessesByName("RobloxPlayerBeta");
                for (int i = 0; i < processesbyname.Length; i++)
                {
                    Console.WriteLine($"NebulaX: Found Roblox at {processesbyname} \n");
                    processesbyname[i].Kill();
                }
            }
            else
            {
                Console.WriteLine("NebulaX: Roblox Is Not Open!\n");
            }
        }
        public static void LaunchRoblox() {
            if (isRobloxOpen())
            {
                Console.WriteLine("NebulaX: RobloxPlayerBeta is Already Open!\n");
            }
            else {
                Process.Start("roblox-player:1");
                Console.WriteLine("NebulaX: RobloxPlayerBeta Has been Opened!\n");
            }
        }

        public static bool AutoAttach()
        {
            try
            {
                if (IsInjected())
                {
                    Console.WriteLine("NebulaX Autoattach: Already Injected!");
                    return true;
                }

                // Check if Roblox is running
                if (!isRobloxOpen())
                {
                    Console.WriteLine("NebulaX Autoattach: Roblox is not running!");
                    return false;
                }

                Console.WriteLine("NebulaX Autoattach: Attempting to Inject DLL into Roblox!");

                Inject();

                // Check if injection was successful
                if (IsInjected())
                {
                    Console.WriteLine("NebulaX Autoattach: Injected into Roblox Successfully!");
                    return true;
                }
                else
                {
                    Console.WriteLine("NebulaX Autoattach: Failed to Inject DLL into Roblox!");
                    return false;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"NebulaX Autoattach: Error during injection - {ex.Message}");
                return false;
            }
        }
        public static void AutoSetup()
        {
            string[] files =
            {
        "NebulaX.dll",
        "libcrypto-3-x64.dll",
        "libssl-3-x64.dll",
        "xxhash.dll",
        "zstd.dll",
        "zlib1.dll",
        "blake3.dll"
    };

            string binPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "bin");

            if (!Directory.Exists(binPath))
                Directory.CreateDirectory(binPath);

            string baseUrl = "https://raw.githubusercontent.com/NebulaXKeyless/auto-setup/main/";

            using (WebClient webClient = new WebClient())
            {
                foreach (string file in files)
                {
                    string localPath = Path.Combine(binPath, file);

                    if (!File.Exists(localPath))
                    {
                        try
                        {
                            string url = baseUrl + file;
                            webClient.DownloadFile(url, localPath);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"Failed to download {file}: {ex.Message}");
                        }
                    }
                }
            }
        }
        private static string GetUserIdFromUsername(string username)
        {
            string address = "https://users.roblox.com/v1/usernames/users";
            string data = "{\"usernames\": [\"" + username + "\"]}";
            try
            {
                using (WebClient webClient = new WebClient())
                {
                    webClient.Headers[HttpRequestHeader.ContentType] = "application/json";
                    string json = webClient.UploadString(address, "POST", data);
                    JObject jobject = JObject.Parse(json);
                    bool flag = jobject["data"] != null && jobject["data"].HasValues;
                    if (flag)
                    {
                        return jobject["data"][0]["id"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error getting user ID for " + username + ": " + ex.Message, "NebulaXAPI");
            }
            return null;
        }
        public static BitmapImage GetAvatar(string username)
        {
            string userIdFromUsername = GetUserIdFromUsername(username);
            bool flag = string.IsNullOrEmpty(userIdFromUsername);
            BitmapImage result;
            if (flag)
            {
                result = null;
            }
            else
            {
                string address = "https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=" + userIdFromUsername + "&size=420x420&format=png";
                try
                {
                    using (WebClient webClient = new WebClient())
                    {
                        string json = webClient.DownloadString(address);
                        JObject jobject = JObject.Parse(json);
                        bool flag2 = jobject["data"] != null && jobject["data"].HasValues;
                        if (flag2)
                        {
                            string uriString = jobject["data"][0]["imageUrl"].ToString();
                            return new BitmapImage(new Uri(uriString));
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error getting avatar for " + username + ": " + ex.Message, "NebulaXAPI");
                }
                result = null;
            }
            return result;
        }
        public static string GetUsername()
        {
            string userName = Environment.UserName;
            string path = "C:\\\\Users\\\\" + userName + "\\\\AppData\\\\Local\\\\Roblox\\\\LocalStorage\\\\appStorage.json";
            bool flag = !File.Exists(path);
            string result;
            if (flag)
            {
                result = null;
            }
            else
            {
                try
                {
                    string json = File.ReadAllText(path);
                    JObject jobject = JObject.Parse(json);
                    bool flag2 = jobject.ContainsKey("Username");
                    if (flag2)
                    {
                        JToken jtoken = jobject["Username"];
                        return (jtoken != null) ? jtoken.ToString() : null;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error getting username " + ex.Message, "NebulaXAPI");
                }
                result = null;
            }
            return result;
        }
        public static void Deject()//kinda broken sorry will fix soon - OG
        {
            IntPtr handle = GetModuleHandle("bin\\NebulaX.dll");
            if (handle != IntPtr.Zero)//checks if handle is valid before trying to freelibrary 
            {
                FreeLibrary(handle);
            }
        }
    }
}
